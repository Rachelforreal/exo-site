// Boot: load data, wire the universe, smooth scroll, and every section.
import { $, $$, reduced, reveal, overlay, clamp } from './util.js';
import { lazyUniverse } from './lazyuni.js';
import { initThemes, setPower, currentPower } from './themes.js';
import { initHero } from './hero.js';
import { initTicker, initNow, initMembers, initChannels } from './sections.js';
import { initSchedule } from './schedule.js';
import { initAlbums } from './albums.js';
import { initSearch } from './search.js';
import { initMode } from './mode.js';
import { initCover } from './cover.js';
import { initRoad } from './road.js';
import { initMaker } from './maker.js';
import { withCalendar } from './calendar.js';
import { initSubscribe } from './subscribe.js';
import { initFeed } from './feed.js';

const V = '2';
const load = name => fetch(`data/${name}.json?v=${V}`).then(r => { if (!r.ok) throw new Error(`${name}: ${r.status}`); return r.json(); });

async function boot() {
  const [members, albums, events, news, channels, hero, meta, archive] = await Promise.all(['members', 'albums', 'events', 'news', 'channels', 'hero', 'meta', 'archive'].map(load));
  const ctx = { members, albums, events, news, channels, hero, meta, archive, byId: Object.fromEntries(members.map(m => [m.id, m])), lenis: null };

  /* ---- background ---- */
  let uni = null;
  try { uni = lazyUniverse($('#universe'), { reduced }); } catch (e) { console.warn('universe', e); }
  initThemes(members, uni);
  if (uni) {
    document.addEventListener('visibilitychange', () => (document.hidden || document.documentElement.dataset.mode !== 'galaxy' ? uni.stop() : uni.start()));
    if (!reduced) window.addEventListener('pointermove', e => { if (e.pointerType === 'mouse') uni.pointer((e.clientX / innerWidth) * 2 - 1, 1 - (e.clientY / innerHeight) * 2); }, { passive: true });
  }

  /* ---- smooth scroll ---- */
  const g = window.gsap, ST = window.ScrollTrigger;
  if (g && ST) g.registerPlugin(ST);
  if (window.Lenis && !reduced && window.matchMedia('(hover: hover) and (pointer: fine)').matches) {
    const lenis = new window.Lenis({ lerp: 0.11, wheelMultiplier: 1, anchors: false });
    ctx.lenis = overlay.lenis = lenis;
    if (g && ST) { lenis.on('scroll', ST.update); g.ticker.add(t => lenis.raf(t * 1000)); g.ticker.lagSmoothing(0); }
    else { const raf = t => { lenis.raf(t); requestAnimationFrame(raf); }; requestAnimationFrame(raf); }
  }
  const goTo = (target, offset = -20) => { const el = typeof target === 'string' ? document.getElementById(target) : target; if (!el) return; ctx.lenis ? ctx.lenis.scrollTo(el, { offset, duration: 1.3 }) : window.scrollTo({ top: el.getBoundingClientRect().top + scrollY + offset, behavior: reduced ? 'auto' : 'smooth' }); };
  document.addEventListener('click', e => {
    const a = e.target.closest('a[href^="#"]'); if (!a || a.dataset.event) return;
    const id = a.getAttribute('href').slice(1); if (!id) return; const el = document.getElementById(id); if (!el) return;
    e.preventDefault(); id === 'top' ? (ctx.lenis ? ctx.lenis.scrollTo(0, { duration: 1.2 }) : window.scrollTo({ top: 0, behavior: 'smooth' })) : goTo(el); history.replaceState(null, '', id === 'top' ? location.pathname + location.search : '#' + id);
  });

  /* ---- sections (late-bound so they can call each other) ---- */
  ctx.calendar = withCalendar(ctx);
  initMode({ uni });
  const api = {};
  const openMember = (id, from) => api.openMember?.(id, from);
  const focusEvent = id => api.focusEvent?.(id);
  const sched = initSchedule(ctx, { openMember });
  api.focusEvent = sched.focusEvent;
  const mem = initMembers(ctx, { focusEvent, filterMember: sched.filterMember });
  // a member opens his own page (单人专栏) instead of a sheet
  api.openMember = id => { if (ctx.byId[id]) location.href = `member.html?id=${encodeURIComponent(id)}`; };
  initTicker(ctx);
  initNow(ctx, { openMember, focusEvent });
  const alb = initAlbums(ctx);
  initChannels(ctx);
  initCover(ctx);
  initRoad(ctx);
  initMaker(ctx);
  initHero(ctx, { openMember, lenis: ctx.lenis });
  initSearch(ctx, { openMember, focusEvent, goAlbum: alb.go, goSection: id => goTo(id), searchSchedule: q => { sched.search(q); goTo('schedule', -40); } });
  $('#hero-next').addEventListener('click', e => { const a = e.target.closest('[data-event]'); if (a) { e.preventDefault(); focusEvent(a.dataset.event); } });
  initSubscribe();
  reveal();

  /* ---- header + nav state, background dimming with scroll ---- */
  const bar = $('#bar'), links = $$('.bar__nav a'), secs = links.map(a => document.getElementById(a.dataset.nav));
  let ticking = false;
  const onScroll = () => {
    ticking = false; const y = window.scrollY, vh = innerHeight;
    bar.classList.toggle('is-stuck', y > 30);
    const k = clamp(y / (vh * 0.9), 0, 1);
    document.documentElement.style.setProperty('--veil', (0.3 + k * 0.32).toFixed(3));
    uni?.setBright(1 - k * 0.3);
    let on = -1; secs.forEach((s, i) => { if (s && s.getBoundingClientRect().top < vh * 0.42) on = i; });
    links.forEach((a, i) => { const is = i === on; if (a.classList.contains('is-on') !== is) { a.classList.toggle('is-on', is); is ? a.setAttribute('aria-current', 'true') : a.removeAttribute('aria-current'); } });
  };
  window.addEventListener('scroll', () => { if (!ticking) { ticking = true; requestAnimationFrame(onScroll); } }, { passive: true });
  onScroll();

  /* ---- section headings: a small scrubbed drift on the big numerals ---- */
  if (g && ST && !reduced) {
    $$('.sec__no').forEach(n => g.fromTo(n, { yPercent: 40 }, { yPercent: -30, ease: 'none', scrollTrigger: { trigger: n.closest('.sec'), start: 'top bottom', end: 'top top', scrub: 0.6 } }));
    g.fromTo('.foot__big', { yPercent: 30, opacity: 0.2 }, { yPercent: 0, opacity: 1, ease: 'none', scrollTrigger: { trigger: '.foot', start: 'top bottom', end: 'bottom bottom', scrub: 0.6 } });
    window.addEventListener('load', () => ST.refresh());
    document.fonts?.ready.then(() => ST.refresh());
  }

  /* ---- deep links ---- */
  const h = decodeURIComponent(location.hash.slice(1));
  if (h) setTimeout(() => { if (ctx.byId[h]) openMember(h); else if (h.startsWith('ev-')) focusEvent(h.slice(3).startsWith('ev-') ? h.slice(3) : h) ; else if (document.getElementById(h)) goTo(h); }, 500);

  initFeed(); // 快讯 (non-blocking; hides itself on failure)
  document.documentElement.classList.add('is-ready');
  window.EXO = { ctx, setPower, currentPower, openMember, focusEvent, goAlbum: alb.go };
}

boot().catch(err => {
  console.error(err);
  document.documentElement.classList.remove('js');
  const m = document.createElement('p'); m.style.cssText = 'position:fixed;left:50%;top:50%;transform:translate(-50%,-50%);max-width:30em;text-align:center;line-height:1.8;padding:24px;z-index:99';
  m.textContent = '页面数据没有加载出来。请刷新再试一次；如果是直接双击打开的文件，需要通过本地服务器访问。';
  document.body.append(m);
});
