// 单人专栏 — member.html?id=kai. One page per member, in the same two editions as the home page.
// In 银河 the universe and particles switch to his power (without changing the visitor's saved theme),
// and the hero carries an aura drawn for that power.
import { $, $$, esc, glyph, icon, badge, sources, safeUrl, reduced, todayStr, dayDiff, relDay, fullDate, md } from './util.js';
import { lazyUniverse } from './lazyuni.js';
import { initThemes, setPower } from './themes.js';
import { initMode } from './mode.js';
import { shareMember } from './share.js'; /* share */
import { initSubscribe } from './subscribe.js';

const load = name => fetch(`data/${name}.json?v=2`).then(r => { if (!r.ok) throw new Error(name); return r.json(); });

async function boot() {
  const [members, events, news, archive, meta] = await Promise.all(['members', 'events', 'news', 'archive', 'meta'].map(load));
  const byId = Object.fromEntries(members.map(m => [m.id, m]));
  const id = new URLSearchParams(location.search).get('id') || (location.pathname.match(/\/m\/([a-z0-9-]+)\/?(?:index\.html)?$/i) || [])[1]; /* ?id= or /m/<id>/ */
  const m = byId[id] || members[0], idx = members.indexOf(m);
  document.title = `${m.en} ${m.zh} · 单人专栏 · EXO 星球`;

  /* universe + power: show his power here, but keep the visitor's own saved theme */
  let uni = null; try { uni = lazyUniverse($('#universe'), { reduced }); } catch {}
  let saved = null; try { saved = localStorage.getItem('exo-power'); } catch {}
  initThemes(members, uni);
  setPower(m.id, { quiet: true });
  try { saved == null ? localStorage.removeItem('exo-power') : localStorage.setItem('exo-power', saved); } catch {}
  initMode({ uni });
  document.addEventListener('visibilitychange', () => { if (!uni) return; document.hidden || document.documentElement.dataset.mode !== 'galaxy' ? uni.stop() : uni.start(); });
  if (uni && !reduced) addEventListener('pointermove', e => { if (e.pointerType === 'mouse') uni.pointer((e.clientX / innerWidth) * 2 - 1, 1 - (e.clientY / innerHeight) * 2); }, { passive: true });

  /* numbers */
  const today = todayStr(), [by, bm, bd] = m.birth.split('-').map(Number), [ty] = today.split('-').map(Number);
  let nb = `${ty}-${m.birth.slice(5)}`; if (nb < today) nb = `${ty + 1}-${m.birth.slice(5)}`;
  const dd = dayDiff(nb), age = ty - by - (today.slice(5) < m.birth.slice(5) ? 1 : 0);

  /* what belongs to him */
  const mine = x => (x.members || []).includes(m.id);
  const evs = events.filter(mine), up = evs.filter(e => e.status !== 'done' && dayDiff(e.endDate || e.date) >= 0).sort((a, b) => a.date.localeCompare(b.date));
  const past = evs.filter(e => !up.includes(e)).sort((a, b) => b.date.localeCompare(a.date));
  const myNews = news.filter(mine).sort((a, b) => b.date.localeCompare(a.date));
  const road = (archive.road || []).filter(r => r.who === m.id || (r.who === 'unit' && (r.s + r.t).includes(m.zh))).sort((a, b) => a.d.localeCompare(b.d));
  const CBX = ['xiumin', 'baekhyun', 'chen'];
  const variety = (archive.variety || []).filter(v => v.who === '全员' || v.who.includes(m.en) || (v.who.includes('CBX') && CBX.includes(m.id)));
  const looks = [[m.photo2, m.photo2Era], [m.photo, m.photoEra]].filter(x => x[0]);
  const links = (m.channels || []).filter(c => safeUrl(c.url));
  const agency = String(m.agency || '').split(/[（(]/)[0].trim();

  const ev = e => `<li class="mp-ev${up.includes(e) ? '' : ' is-past'}"><time datetime="${e.date}"><b>${md(e.date)}</b><span>${e.date.slice(0, 4)}${e.endDate && e.endDate !== e.date ? ` – ${md(e.endDate)}` : ''}</span></time>
    <div><p class="mp-ev__k">${badge(e.verification)}<span>${esc(e.category)}${e.timeKST ? ` · ${e.timeKST} KST` : ''}${up.includes(e) ? ` · ${relDay(dayDiff(e.date))}` : ''}</span></p>
    <h3>${esc(e.title)}</h3>${e.city || e.venue ? `<p class="mp-ev__w">${icon('pin')}${esc([e.city, e.venue].filter(Boolean).join(' · '))}</p>` : ''}
    ${e.sources?.length ? `<div class="item__src"><span>来源</span>${sources(e.sources.slice(0, 2))}</div>` : ''}</div></li>`;
  const sec = (key, no, kicker, title, body, lead = '') => body ? `<section class="sec mp-sec mp-sec--${key}" aria-labelledby="mp-${key}">
    <header class="sec__head"><p class="sec__no">${no}</p><div><p class="kicker">${kicker}</p><h2 class="sec__h" id="mp-${key}">${title}</h2></div>${lead ? `<p class="sec__lead">${lead}</p>` : ''}</header>${body}</section>` : '';

  $('#mp').innerHTML = `
  <section class="mp-hero" style="--mc:${m.color};--mc2:${m.color2 || m.color}">
    <div class="mp-hero__aura" aria-hidden="true"><i></i><i></i><i></i></div>
    <div class="mp-hero__text">
      <p class="eyebrow"><span>MEMBER ${m.no} / ${String(members.length).padStart(2, '0')}</span><i></i><span>${esc(m.role)}</span></p>
      <h1 class="mp-hero__name" style="--len:${m.en.length}">${esc(m.en)}</h1>
      <p class="mp-hero__real">${esc(m.zh)} · ${esc(m.ko)} · ${esc(m.koReal)}</p>
      <div class="mp-power">${glyph(m.id, 'glyph mp-power__glyph')}
        <div><p class="mp-power__t"><b>${esc(m.power.zh)}</b><span>${esc(m.power.en)}</span></p><p class="mp-power__line">${esc(m.power.line)}</p></div></div>
      <dl class="mp-stats">
        <div><dt>生日</dt><dd>${fullDate(m.birth)}</dd></div>
        <div><dt>年龄</dt><dd>${age} 岁</dd></div>
        <div class="is-hot"><dt>下次生日</dt><dd>${dd === 0 ? '今天' : 'D-' + dd}</dd></div>
        ${agency ? `<div><dt>所属</dt><dd title="${esc(m.agency)}">${esc(agency)}</dd></div>` : ''}
      </dl>
      <div class="mp-btns"><button class="cbtn" type="button" data-keep-power>把整站换成「${esc(m.power.zh)}」</button><a class="cbtn cbtn--ghost" href="index.html?card=${m.id}#maker">做他的 L 卡 →</a><button class="cbtn cbtn--ghost" type="button" data-subscribe="member" data-member-id="${m.id}" data-title="${esc(m.zh)} · 单人日程">订阅他的日程</button><!-- share:begin --><button class="cbtn cbtn--ghost" type="button" data-share-member>分享他的专栏</button><!-- share:end --></div>
    </div>
    <figure class="mp-hero__ph">
      <img src="${esc(looks[0][0])}" alt="${esc(m.en)} 概念照" id="mp-img">
      ${looks.length > 1 ? `<div class="mp-looks" role="group" aria-label="切换照片">${looks.map((l, i) => `<button type="button" data-look="${i}" aria-pressed="${i === 0}" aria-label="${esc(l[1])}"><img src="${esc(l[0])}" alt="" loading="lazy" decoding="async"></button>`).join('')}</div>` : ''}
      <figcaption id="mp-era">${esc(looks[0][1] || '')} · © SM Entertainment</figcaption>
    </figure>
  </section>

  ${sec('now', '01', 'NOW · 近况', `现在在做<em>什么</em>`, `<div class="mp-now"><p class="mp-now__s">${esc(m.status || '近况待补充。')}</p>${m.latest ? `<p class="mp-now__l"><span>最近发行</span>${esc(m.latest)}</p>` : ''}
    ${m.statusSources?.length ? `<div class="item__src"><span>来源</span>${sources(m.statusSources)}</div>` : ''}</div>`)}
  ${sec('sched', '02', 'SCHEDULE · 日程', `接下来<em>去哪里</em>`, `${up.length ? `<ol class="mp-evs">${up.map(ev).join('')}</ol>` : `<p class="mp-none">暂时没有已公布、带确切日期的个人日程。</p>`}
    ${past.length ? `<details class="mp-past"><summary>已结束的日程 ${past.length} 条</summary><ol class="mp-evs">${past.map(ev).join('')}</ol></details>` : ''}`, '时间均为首尔时间（KST），每条注明核验等级。')}
  ${sec('news', '03', 'BULLETIN · 动态', `和他有关的<em>消息</em>`, myNews.length ? `<ol class="mp-news">${myNews.map(n => `<li><p class="mp-ev__k">${badge(n.verification)}<span>${esc(n.channel)} · ${fullDate(n.date)}</span></p><h3>${esc(n.title)}</h3><p>${esc(n.summary)}</p>${n.sources?.length ? `<div class="item__src"><span>来源</span>${sources(n.sources)}</div>` : ''}</li>`).join('')}</ol>` : '')}
  <div class="mp-cols">
  ${sec('works', '04', 'WORKS · 作品', `个人<em>作品</em>`, m.solo?.length ? `<ol class="mp-works">${m.solo.map(s => { const i = s.lastIndexOf(' · '); return `<li><b>${esc(i > 0 ? s.slice(0, i) : s)}</b><span>${esc(i > 0 ? s.slice(i + 3) : '')}</span></li>`; }).join('')}</ol>` : '')}
  ${sec('ch', '05', 'CHANNELS · 渠道', `在哪里<em>找到他</em>`, `${links.length ? `<div class="mp-links">${links.map(c => `<a href="${esc(c.url)}" target="_blank" rel="noopener noreferrer">${esc(c.name)}${icon('arrow')}</a>`).join('')}</div>` : ''}${m.channelsNote ? `<p class="mp-none">${esc(m.channelsNote)}</p>` : ''}`)}
  </div>
  ${sec('road', '06', 'ROAD · 来时路', `他走过的<em>路</em>`, road.length ? `<ol class="mp-road">${road.map(r => `<li style="--pc:${m.color}"><time datetime="${r.d}">${r.approx || r.d.replace(/-/g, '.')}</time><div><b>${esc(r.t)}</b><span>${esc(r.s)}</span></div></li>`).join('')}</ol>` : '')}
  ${sec('variety', '07', 'VARIETY · 综艺', `在综艺<em>里</em>`, variety.length ? `<ol class="mp-variety">${variety.map(v => `<li><span>${esc(v.y)}</span><b>${esc(v.zh)}</b><small>${esc(v.p)}${v.note ? ` · ${esc(v.note)}` : ''}</small><a href="https://search.bilibili.com/all?keyword=${encodeURIComponent('EXO ' + v.t)}" target="_blank" rel="noopener noreferrer">B 站 ↗</a></li>`).join('')}</ol>` : '')}`;

  /* other members: names and powers only, no second wall of photos */
  const prev = members[(idx + members.length - 1) % members.length], next = members[(idx + 1) % members.length];
  $('.mp__roster').innerHTML = `<p class="kicker">其他成员</p><div class="mp__grid">${members.map(x => `<a href="member.html?id=${x.id}"${x.id === m.id ? ' aria-current="page"' : ''} style="--mc:${x.color}">${glyph(x.id)}<b>${esc(x.en)}</b><span>${esc(x.power.zh)}</span></a>`).join('')}</div>
    <nav class="mp__pn"><a href="member.html?id=${prev.id}">← ${esc(prev.en)}</a><a href="index.html#members">全部成员</a><a href="member.html?id=${next.id}">${esc(next.en)} →</a></nav>`;
  if (meta.checkedAt) $('[data-checked]').textContent = `资料截至 ${fullDate(meta.checkedAt)}`;

  $('#mp').addEventListener('click', e => {
    const look = e.target.closest('[data-look]');
    if (look) { const i = +look.dataset.look; $$('[data-look]').forEach((b, k) => b.setAttribute('aria-pressed', String(k === i))); $('#mp-img').src = looks[i][0]; $('#mp-era').textContent = `${looks[i][1] || ''} · © SM Entertainment`; return; }
    if (e.target.closest('[data-share-member]')) { shareMember(m); return; } /* share */
    const kp = e.target.closest('[data-keep-power]');
    if (kp) { try { localStorage.setItem('exo-power', m.id); } catch {} kp.textContent = `整站已换成「${m.power.zh}」`; }
  });
  document.documentElement.classList.add('is-ready');
}

initSubscribe();
boot().catch(err => { console.error(err); const p = $('.mp__loading'); if (p) p.textContent = '专栏没有加载出来，请刷新再试。'; });
