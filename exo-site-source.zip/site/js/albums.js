// Discography: a draggable shelf of sleeves + one stage that re-skins itself for the selected album.
import { $, $$, esc, icon, reduced, overlay, dragScroll, fullDate, store } from './util.js';
import { createAlbumFx } from './albumfx.js';

const lum = hex => { const n = parseInt(hex.slice(1), 16); return (0.2126 * (n >> 16 & 255) + 0.7152 * (n >> 8 & 255) + 0.0722 * (n & 255)) / 255; };
const norm = s => s.toLowerCase().replace(/[’']/g, "'").replace(/\s*[\(（].*$/, '').trim();

/* 荣誉: year-end awards and music-show wins for this album (data/new/awards.json) */
const VER = { official: '官方', media: '媒体', wiki: '百科' };
function honorsHTML(a) {
  const aw = a.awards; if (!aw) return '';
  const ye = aw.yearEnd || [], sw = aw.showWins || {}, dae = ye.filter(x => x.daesang).length, total = sw.total || 0;
  if (!ye.length && !total) return `<div class="honors honors--none"><p class="honors__h">荣誉</p><p class="honors__none">暂未收录这张专辑的获奖记录。</p></div>`;
  const bySong = Object.entries(sw.bySong || {}).filter(([, n]) => n > 0);
  const src = u => u ? ` <a href="${esc(u)}" target="_blank" rel="noopener noreferrer" aria-label="来源">↗</a>` : '';
  return `<details class="honors">
    <summary><span class="honors__h">荣誉</span>
      ${dae ? `<span class="honors__n honors__n--dae"><b>${dae}</b>大赏</span>` : ''}
      ${ye.length ? `<span class="honors__n"><b>${ye.length}</b>年终奖项</span>` : ''}
      ${total ? `<span class="honors__n"><b>${total}</b>音乐节目一位</span>` : ''}
      <i class="honors__more">展开</i></summary>
    ${ye.length ? `<ul class="honors__list">${ye.slice().sort((x, y) => (y.daesang - x.daesang) || (x.year - y.year)).map(x => `<li${x.daesang ? ' class="is-dae"' : ''}><span class="honors__y">${x.year}</span><span><b>${esc(x.ceremony)}</b>${esc(x.category)}${x.song ? ` · ${esc(x.song)}` : ''}${x.daesang ? '<em>大赏</em>' : ''}${x.note ? `<small>${esc(x.note)}</small>` : ''}</span><span class="honors__src">${VER[x.verification] || ''}${src(x.source)}</span></li>`).join('')}</ul>` : ''}
    ${total ? `<p class="honors__shows">音乐节目一位 <b>${total}</b> 次${bySong.length ? '：' + bySong.map(([t, n]) => `《${esc(t)}》${n} 次`).join('，') : ''}${sw.note ? `<small>${esc(sw.note)}</small>` : ''}${src(sw.source)}</p>` : ''}
  </details>`;
}

export function initAlbums(ctx) {
  const albums = ctx.albums, shelf = $('#shelf'), track = $('#shelf-track'), stage = $('#stage');
  track.innerHTML = albums.map((a, i) => `<button class="sleeve" type="button" role="tab" id="tab-${a.slug}" aria-selected="false" aria-controls="stage" data-i="${i}" tabindex="-1">
    <img src="${esc(a.thumb || a.cover)}" alt="${esc(a.title)} 封面" loading="lazy" draggable="false"><span>${a.date.slice(0, 4)}</span><small>${esc(a.title)}</small></button>`).join('');
  dragScroll(shelf);

  stage.innerHTML = `<canvas class="stage__fx" aria-hidden="true"></canvas><div class="stage__glow" aria-hidden="true"></div><span class="stage__no" aria-hidden="true"></span>
    <div class="stage__art"><div class="disc" aria-hidden="true"></div><div class="cover"><img alt="" decoding="async"></div></div>
    <div class="stage__info"></div>
    <div class="stage__nav"><button type="button" data-step="-1" aria-label="上一张">←</button><button type="button" data-step="1" aria-label="下一张">→</button></div>`;
  const fx = createAlbumFx($('.stage__fx', stage));
  const art = $('.stage__art', stage), cover = $('.cover', stage), img = $('img', cover), info = $('.stage__info', stage), glow = $('.stage__glow', stage), no = $('.stage__no', stage);
  let cur = -1;

  const infoHTML = a => {
    const leads = (a.lead || '').split(' · ').map(norm);
    const isLead = t => leads.some(l => norm(t) === l || norm(t).startsWith(l + ' '));
    const q = encodeURIComponent(`EXO ${(a.lead || a.title).split(' · ')[0]} MV`);
    return `<p class="stage__k"><span>${fullDate(a.date)}</span><i></i><span>${esc(a.type)}</span>${a.tracks.length ? `<i></i><span>${a.tracks.length} 首</span>` : ''}</p>
      <h3 class="stage__title">${esc(a.title)}</h3>
      <p class="stage__zh">${esc(a.zh)}<span>主打 · ${esc(a.lead)}</span></p>
      <p class="stage__tag">${esc(a.tagline)}</p>
      <p class="stage__concept">${esc(a.concept)}</p>
      ${a.motif || a.tags?.length ? `<p class="stage__era">${a.motif ? `<b>${esc(a.motif)}</b>` : ''}${(a.tags || []).map(t => `<span>${esc(t)}</span>`).join('')}</p>` : ''}
      ${a.lyric ? `<blockquote class="stage__lyric"><p lang="ko">${esc(a.lyric[0])}</p><p>${esc(a.lyric[1])}</p></blockquote>` : ''}
      <div class="stage__cta">
        ${a.bv ? `<button class="abtn abtn--main" type="button" data-mv>${icon('play')}看 MV<small>${a.bvKind === 'official' ? 'Bilibili · SMTOWN' : a.bvKind === 'fan' ? 'Bilibili · 粉丝上传' : 'Bilibili'}</small></button>` : `<a class="abtn abtn--main" href="https://search.bilibili.com/all?keyword=${q}" target="_blank" rel="noopener noreferrer">${icon('play')}在 B 站找 MV</a>`}
        ${a.yt ? `<a class="abtn" href="https://www.youtube.com/watch?v=${esc(a.yt)}" target="_blank" rel="noopener noreferrer">YouTube<small>外链</small></a>` : ''}
      </div>
      ${a.tracks.length ? `<ol class="tracks">${a.tracks.map(t => `<li${isLead(t) ? ' class="is-lead"' : ''}><span>${esc(t)}</span></li>`).join('')}</ol>` : ''}
      ${honorsHTML(a)}`;
  };

  function select(i, { scroll = true, quiet = false } = {}) {
    i = (i + albums.length) % albums.length; if (i === cur) return;
    const dir = cur < 0 ? 1 : (i > cur ? 1 : -1); cur = i; const a = albums[i], s = a.skin, light = lum(s.bg) > 0.55;
    $$('.sleeve', track).forEach((b, k) => { b.setAttribute('aria-selected', String(k === i)); b.tabIndex = k === i ? 0 : -1; });
    if (scroll) { const b = track.children[i]; shelf.scrollTo({ left: b.offsetLeft + b.offsetWidth / 2 - shelf.clientWidth / 2, behavior: quiet || reduced ? 'auto' : 'smooth' }); }
    stage.style.setProperty('--a-bg', s.bg); stage.style.setProperty('--a-bg2', s.bg2); stage.style.setProperty('--a-fg', s.fg); stage.style.setProperty('--a-ac', s.ac); stage.style.setProperty('--a-ac2', s.ac2 || s.ac);
    stage.dataset.face = a.face; stage.dataset.tone = light ? 'light' : 'dark'; stage.dataset.len = a.title.length > 12 ? 'long' : 'short';
    stage.setAttribute('aria-labelledby', `tab-${a.slug}`);
    fx.set(a.fx, s, light);
    glow.style.backgroundImage = `url("${a.thumb || a.cover}")`; no.textContent = a.no;
    const g = window.gsap, swap = () => { img.src = a.cover; img.alt = `${a.title} 专辑封面`; info.innerHTML = infoHTML(a); };
    if (g && !reduced && !quiet) {
      g.killTweensOf([cover, info.children]);
      g.timeline()
        .to(cover, { rotateY: 90 * dir, duration: 0.28, ease: 'power2.in' })
        .to(info, { opacity: 0, x: -14 * dir, duration: 0.22, ease: 'power2.in' }, 0)
        .add(swap)
        .set(info, { opacity: 1, x: 0 })
        .fromTo(cover, { rotateY: -90 * dir }, { rotateY: 0, duration: 0.7, ease: 'expo.out', clearProps: 'transform' })
        .add(() => g.from(info.children, { opacity: 0, y: 22, duration: 0.7, stagger: 0.055, ease: 'expo.out', clearProps: 'opacity,transform' }), '<');
    } else swap();
    store.set('exo-album', a.slug);
  }

  track.addEventListener('click', e => { const b = e.target.closest('.sleeve'); if (b) select(+b.dataset.i); });
  track.addEventListener('keydown', e => {
    const k = { ArrowRight: 1, ArrowLeft: -1 }[e.key]; if (!k && e.key !== 'Home' && e.key !== 'End') return; e.preventDefault();
    select(e.key === 'Home' ? 0 : e.key === 'End' ? albums.length - 1 : cur + k); track.children[cur].focus({ preventScroll: true });
  });
  stage.addEventListener('click', e => {
    const st = e.target.closest('[data-step]'); if (st) { select(cur + +st.dataset.step); return; }
    if (e.target.closest('[data-mv]')) openMV(albums[cur]);
  });
  // swipe on the stage (touch)
  let tx = 0, ty = 0; stage.addEventListener('touchstart', e => { tx = e.touches[0].clientX; ty = e.touches[0].clientY; }, { passive: true });
  stage.addEventListener('touchend', e => { const dx = e.changedTouches[0].clientX - tx, dy = e.changedTouches[0].clientY - ty; if (Math.abs(dx) > 70 && Math.abs(dx) > Math.abs(dy) * 1.8) select(cur + (dx < 0 ? 1 : -1)); }, { passive: true });
  // cover tilt
  if (!reduced && window.matchMedia('(hover: hover)').matches) {
    art.addEventListener('pointermove', e => { const r = art.getBoundingClientRect(); cover.style.setProperty('--ry', `${((e.clientX - r.left) / r.width - 0.5) * 16}deg`); cover.style.setProperty('--rx', `${(0.5 - (e.clientY - r.top) / r.height) * 12}deg`); });
    art.addEventListener('pointerleave', () => { cover.style.setProperty('--rx', '0deg'); cover.style.setProperty('--ry', '0deg'); });
  }

  /* ---- MV lightbox ---- */
  const mv = $('#mv'), frame = $('#mv-frame'), cap = $('#mv-cap');
  function openMV(a) {
    if (!a.bv) return;
    frame.innerHTML = `<iframe src="https://player.bilibili.com/player.html?bvid=${encodeURIComponent(a.bv)}&autoplay=1&high_quality=1&danmaku=0" title="${esc(a.lead)} MV" allow="autoplay; fullscreen; picture-in-picture" allowfullscreen referrerpolicy="no-referrer"></iframe>`;
    cap.innerHTML = `<b>${esc(a.lead)}</b><span>${esc(a.title)} · ${a.date.slice(0, 4)}${a.bvKind === 'fan' ? ' · 此视频为粉丝上传，非官方频道' : a.bvKind === 'official' ? ' · SMTOWN 上传' : ''}</span><a class="src" href="https://www.bilibili.com/video/${esc(a.bv)}" target="_blank" rel="noopener noreferrer">在 Bilibili 打开${icon('arrow')}</a>${a.yt ? `<a class="src" href="https://www.youtube.com/watch?v=${esc(a.yt)}" target="_blank" rel="noopener noreferrer">YouTube${icon('arrow')}</a>` : ''}`;
    overlay.open(mv, { focus: $('.mv__x', mv) });
  }
  mv.addEventListener('overlay:closed', () => { frame.innerHTML = ''; });

  const saved = store.get('exo-album', null); const start = albums.findIndex(a => a.slug === saved);
  select(start >= 0 ? start : albums.length - 1, { quiet: true, scroll: false });
  requestAnimationFrame(() => { const b = track.children[cur]; shelf.scrollLeft = b.offsetLeft + b.offsetWidth / 2 - shelf.clientWidth / 2; });

  const go = slug => { const i = albums.findIndex(a => a.slug === slug); if (i < 0) return; select(i); const sec = $('#albums'); ctx.lenis ? ctx.lenis.scrollTo(sec, { offset: -30, duration: 1.2 }) : sec.scrollIntoView(); };
  return { go, openMV };
}
