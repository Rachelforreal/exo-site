// Ticker, Now (next-up + official / unverified lanes), member dex + dossier sheet, channels.
import { $, $$, esc, glyph, icon, badge, sources, safeUrl, reveal, overlay, reduced, dayDiff, relDay, md, fullDate, weekday, cst, instant, dateRange, isUpcoming, todayStr } from './util.js';
import { setPower, currentPower } from './themes.js';

export const memberChips = (ctx, ids, tag = 'span') => (ids || []).map(id => {
  if (id === 'group') return `<${tag} class="mchip"${tag === 'button' ? ' type="button" data-member="group"' : ''}><i>${glyph('galaxy')}</i>EXO</${tag}>`;
  const m = ctx.byId[id]; if (!m) return '';
  return `<${tag} class="mchip"${tag === 'button' ? ` type="button" data-member="${m.id}"` : ''} style="--mc:${m.color}"><i><img src="${esc(m.thumb)}" alt="" loading="lazy"></i>${esc(m.en)}</${tag}>`;
}).join('');

/* ---------- ticker ---------- */
export function initTicker(ctx) {
  const parts = ['<span>We are one<b>EXO</b></span>', ...ctx.members.map(m => `<span>${glyph(m.id)}${esc(m.en)}<b>${esc(m.power.en)}</b></span>`), `<span>${glyph('galaxy')}EXO, 사랑하자<b>EXO-L</b></span>`].join('');
  $('#ticker').innerHTML = parts + parts;
}

/* ---------- now ---------- */
export function initNow(ctx, { openMember, focusEvent }) {
  const now = Date.now();
  const cands = ctx.events.filter(e => e.verification !== 'unverified' && e.status !== 'done' && dayDiff(e.date) >= 0)
    .sort((a, b) => (a.date + (a.timeKST || '23:59')).localeCompare(b.date + (b.timeKST || '23:59')));
  const idx = cands.findIndex(e => instant(e.date, e.timeKST || '23:59') > now);
  const next = cands[idx], after = cands.slice(idx + 1, idx + 4);
  const card = $('#next-card');
  if (next) {
    const hasTime = !!next.timeKST;
    const when = hasTime ? `${fullDate(next.date)} ${weekday(next.date)} · 首尔 ${next.timeKST} / 北京 ${cst(next.timeKST)}` : `${dateRange(next)} ${weekday(next.date)}${next.timeLocal ? ' · ' + next.timeLocal : ' · 具体时间待公布'}`;
    card.innerHTML = `
      <div class="next__main">
        <p class="next__k"><span class="kicker">NEXT UP · 下一站</span>${badge(next.verification)}<span class="tag">${esc(next.category)}</span></p>
        <h3 class="next__title">${esc(next.title)}</h3>
        <p class="next__meta">${memberChips(ctx, next.members, 'button')}${next.city || next.venue ? `<span>${icon('pin')}${esc([next.city, next.venue].filter(Boolean).join(' · '))}</span>` : ''}</p>
        <p class="next__sum">${esc(next.summary)}</p>
        <p class="next__foot">${sources(next.sources)}<button class="link" type="button" data-event="${esc(next.id)}">在行程里查看</button></p>
      </div>
      <div class="next__side"><i class="next__ring"></i><i class="next__ring"></i>
        <div class="count" id="count" role="timer" aria-label="倒计时"></div>
        <p class="next__when">${esc(when)}</p>
      </div>
      ${after.length ? `<div class="next__after">${after.map(e => `<a href="#schedule" data-event="${esc(e.id)}"><time datetime="${e.date}">${md(e.date)}</time><b>${esc(e.title)}</b><small>${relDay(dayDiff(e.date))} · ${esc(e.category)}</small></a>`).join('')}</div>` : ''}`;
    const el = $('#count'); const target = instant(next.date, next.timeKST);
    const pad = n => String(n).padStart(2, '0');
    const draw = () => {
      let s = Math.max(0, Math.floor((target - Date.now()) / 1000));
      const d = Math.floor(s / 86400); s -= d * 86400; const h = Math.floor(s / 3600); s -= h * 3600; const m = Math.floor(s / 60); s -= m * 60;
      el.innerHTML = hasTime
        ? `<div><b>${d}</b><span>天</span></div><i>:</i><div><b>${pad(h)}</b><span>时</span></div><i>:</i><div><b>${pad(m)}</b><span>分</span></div><i>:</i><div><b>${pad(s)}</b><span>秒</span></div>`
        : `<div><b>${Math.max(0, dayDiff(next.date))}</b><span>天后</span></div>`;
    };
    draw(); if (hasTime) setInterval(draw, 1000);
  } else {
    card.innerHTML = `<div class="next__main"><p class="next__k"><span class="kicker">NEXT UP · 下一站</span></p><h3 class="next__title">暂时没有已确认的行程</h3><p class="next__sum">有了正式公告会第一时间放在这里。</p></div>`;
  }

  const item = n => {
    const [, m, d] = n.date.split('-');
    return `<li class="item rv">
      <div class="item__date"><b>${d}</b><span>${+m} 月</span></div>
      <div class="item__tags">${badge(n.verification)}${n.channel ? `<span class="tag">${esc(n.channel)}</span>` : ''}${memberChips(ctx, n.members, 'button')}</div>
      <h4>${esc(n.title)}</h4><p>${esc(n.summary)}</p>
      ${n.missing ? `<p class="item__miss"><b>还缺什么</b>${esc(n.missing)}</p>` : ''}
      <div class="item__src"><span>来源</span>${sources(n.sources)}</div>
    </li>`;
  };
  const lane = (el, list, emptyText, limit) => {
    if (!list.length) { el.innerHTML = `<li class="lane__empty">${emptyText}</li>`; return; }
    el.innerHTML = list.slice(0, limit).map(item).join('');
    if (list.length > limit) {
      const more = document.createElement('button'); more.type = 'button'; more.className = 'link lane__more'; more.textContent = `展开其余 ${list.length - limit} 条`;
      more.addEventListener('click', () => { el.insertAdjacentHTML('beforeend', list.slice(limit).map(item).join('')); more.remove(); reveal(el); });
      el.after(more);
    }
  };
  const official = ctx.news.filter(n => n.verification !== 'unverified');
  const rumor = [...ctx.news.filter(n => n.verification === 'unverified')];
  lane($('#lane-official'), official, '最近没有新的正式消息。', 5);
  lane($('#lane-rumor'), rumor, '目前没有在流传的未证实消息。', 4);
  $('[data-count=official]').textContent = official.length || '';
  $('[data-count=rumor]').textContent = rumor.length || '';

  $('#now').addEventListener('click', e => {
    const ev = e.target.closest('[data-event]'); if (ev) { e.preventDefault(); focusEvent(ev.dataset.event); return; }
    const m = e.target.closest('button[data-member]'); if (m && m.dataset.member !== 'group') openMember(m.dataset.member, m);
  });
}

/* ---------- members ---------- */
export function initMembers(ctx, { focusEvent, filterMember }) {
  const dex = $('#dex');
  const upcomingOf = id => ctx.events.filter(e => isUpcoming(e) && e.members.includes(id)).sort((a, b) => a.date.localeCompare(b.date));
  dex.innerHTML = ctx.members.map((m, i) => {
    const up = upcomingOf(m.id);
    return `<button class="mcard rv" type="button" data-member="${m.id}" style="--mc:${m.color};--mc2:${m.color2};--i:${i % 3}" aria-label="${esc(m.en)} ${esc(m.zh)} 的单人专栏">
      <div class="mcard__pic"><img src="${esc(m.photo)}" alt="${esc(m.en)}" loading="lazy" decoding="async"></div>
      <div class="mcard__body">${glyph(m.id, 'glyph mcard__mark')}
        <div class="mcard__top"><span class="mcard__no">${m.no}</span><span class="type">${glyph(m.id)}${esc(m.power.zh)}<small>${esc(m.power.en)}</small></span></div>
        <h3 class="mcard__en">${esc(m.en)}</h3>
        <p class="mcard__zh">${esc(m.zh)}<span>${esc(m.ko)}</span></p>
        <p class="mcard__st">${esc(m.status || '近况待补充。')}</p>
        <p class="mcard__go">打开单人专栏<b>${up.length ? `${up.length} 个待办行程` : '暂无已公布行程'}</b></p>
      </div></button>`;
  }).join('');
  if (!reduced && window.matchMedia('(hover: hover)').matches) {
    dex.addEventListener('pointermove', e => {
      const c = e.target.closest('.mcard'); if (!c) return; const r = c.getBoundingClientRect();
      const x = (e.clientX - r.left) / r.width, y = (e.clientY - r.top) / r.height;
      c.style.setProperty('--px', `${x * 100}%`); c.style.setProperty('--py', `${y * 100}%`);
      c.style.transform = `perspective(900px) rotateX(${(0.5 - y) * 5}deg) rotateY(${(x - 0.5) * 6}deg) translateY(-4px)`;
    });
    dex.addEventListener('pointerout', e => { const c = e.target.closest('.mcard'); if (c && !c.contains(e.relatedTarget)) c.style.transform = ''; });
  }

  const sheet = $('#sheet'), panel = $('#sheet-panel');
  function openMember(id, from) {
    const m = ctx.byId[id]; if (!m) return;
    const up = upcomingOf(m.id), groupUp = ctx.events.filter(e => isUpcoming(e) && e.members.includes('group')).sort((a, b) => a.date.localeCompare(b.date));
    const list = [...up.slice(0, 5)];
    const looks = [m.photo, m.photo2].filter(Boolean), eras = [m.photoEra, m.photo2Era];
    const links = (m.channels || []).filter(c => safeUrl(c.url));
    panel.style.setProperty('--mc', m.color); panel.style.setProperty('--mc2', m.color2);
    panel.innerHTML = `
      <header class="sheet__hero">
        <img src="${esc(looks[0])}" alt="${esc(m.en)} ${esc(eras[0] || '')}" id="sheet-img">
        ${looks.length > 1 ? `<div class="sheet__looks" role="group" aria-label="切换照片">${looks.map((s, i) => `<button type="button" data-look="${i}" aria-pressed="${i === 0}" aria-label="${esc(eras[i] || '照片 ' + (i + 1))}"><img src="${esc(s)}" alt=""></button>`).join('')}</div>` : ''}
        <button class="iconbtn sheet__x" type="button" data-close aria-label="关闭">${icon('close')}</button>
        <div class="sheet__name"><span class="type">${glyph(m.id)}${esc(m.power.zh)}<small>${esc(m.power.en)}</small></span><h2>${esc(m.en)}</h2><p>${esc(m.zh)} · ${esc(m.ko)} · ${esc(m.koReal)}</p></div>
        <span class="sheet__era" id="sheet-era">${esc(eras[0] || '')}${eras[0] ? ' · © SM Entertainment' : ''}</span>
      </header>
      <div class="sheet__body">
        <section class="sheet__power">${glyph(m.id)}<p>${esc(m.power.line)}</p>
          <button type="button" data-set-power="${m.id}">${currentPower() === m.id ? '已经是这个主题了' : `把星球换成「${esc(m.power.zh)}」`}</button></section>
        <section><h3>现在</h3><p class="sheet__status">${esc(m.status || '近况待补充。')}</p>
          ${m.statusSources?.length ? `<div class="item__src" style="margin-top:12px"><span>来源</span>${sources(m.statusSources)}</div>` : ''}</section>
        <section><h3>档案</h3><dl class="facts">
          <div><dt>生日</dt><dd>${esc(fullDate(m.birth))}</dd></div><div><dt>担当</dt><dd>${esc(m.role)}</dd></div>
          <div><dt>所属</dt><dd>${esc(m.agency || '—')}</dd></div><div><dt>最近发行</dt><dd>${esc(m.latest || '—')}</dd></div></dl></section>
        <section><h3>接下来</h3>${list.length ? `<ul class="sheet__list">${list.map(e => `<li><time datetime="${e.date}">${md(e.date)}</time><b>${esc(e.title)}<small>${relDay(dayDiff(e.date))} · ${esc(e.category)}${e.city ? ' · ' + esc(e.city) : ''}</small></b>${badge(e.verification)}</li>`).join('')}</ul>
          <p style="margin-top:14px"><button class="link" type="button" data-filter-member="${m.id}">在行程里看 ${esc(m.en)} 的全部 ${up.length} 条</button></p>`
          : `<p class="sheet__none">没有找到已公布、带确切日期的个人行程。${groupUp.length ? `团体还有 ${groupUp.length} 条待办行程。` : ''}</p>`}</section>
        <section><h3>个人作品</h3><ul class="sheet__solo">${m.solo.map(s => `<li>${esc(s)}</li>`).join('')}</ul></section>
        <section><h3>官方渠道</h3>${links.length ? `<div class="sheet__links">${links.map(c => `<a href="${esc(c.url)}" target="_blank" rel="noopener noreferrer">${esc(c.name)}${icon('arrow')}</a>`).join('')}</div>` : ''}
          ${m.channelsNote ? `<p class="sheet__none" style="margin-top:${links.length ? 12 : 0}px;font-size:13.5px">${esc(m.channelsNote)}</p>` : (!links.length ? '<p class="sheet__none">暂未收录已核实的个人账号。</p>' : '')}</section>
      </div>`;
    panel.scrollTop = 0;
    overlay.open(sheet, { focus: $('.sheet__x', panel) });
  }
  panel.addEventListener('click', e => {
    const look = e.target.closest('[data-look]');
    if (look) { const i = +look.dataset.look; const b = $$('[data-look]', panel); b.forEach((x, k) => x.setAttribute('aria-pressed', String(k === i))); $('#sheet-img').src = $('img', look).src; $('#sheet-era').textContent = (look.getAttribute('aria-label') || '') + ' · © SM Entertainment'; return; }
    const sp = e.target.closest('[data-set-power]');
    if (sp) { const r = sp.getBoundingClientRect(); setPower(sp.dataset.setPower, { x: r.left + r.width / 2, y: r.top + r.height / 2 }); sp.textContent = '已经是这个主题了'; return; }
    const fm = e.target.closest('[data-filter-member]');
    if (fm) { overlay.close(sheet); filterMember(fm.dataset.filterMember); }
  });
  dex.addEventListener('click', e => { const c = e.target.closest('.mcard'); if (c) location.href = `member.html?id=${encodeURIComponent(c.dataset.member)}`; });
  return { openMember };
}

/* ---------- channels ---------- */
const COV = { live: ['已纳入核对', 100], partial: ['逐步覆盖中', 55], planned: ['计划中', 12] };
const TIER = { official: '官方', retail: '商家 · 票务', media: '媒体', fan: '粉丝' };
export function initChannels(ctx) {
  $('#chan').innerHTML = ctx.channels.map((c, i) => {
    const [label, w] = COV[c.coverage] || COV.planned; const u = safeUrl(c.url); const tag = u ? 'a' : 'div';
    return `<${tag} class="ch rv" style="--i:${i % 4}"${u ? ` href="${esc(u)}" target="_blank" rel="noopener noreferrer"` : ''}>
      <div class="ch__top"><small>${esc(TIER[c.tier] || '')} · ${esc(c.zh)}</small><span class="cov cov--${c.coverage}"><i style="--w:${w}%"></i>${label}</span></div>
      <h3>${esc(c.name)}</h3><p class="ch__use">${esc(c.use)}</p><p class="ch__how">${esc(c.how)}</p>
      ${u ? `<svg class="ch__go" viewBox="0 0 24 24" aria-hidden="true"><use href="#i-arrow"/></svg>` : ''}</${tag}>`;
  }).join('');
  const ev = ctx.events, nw = ctx.news;
  const un = ev.filter(e => e.verification === 'unverified').length + nw.filter(n => n.verification === 'unverified').length;
  const links = (ctx.meta.groupChannels || []).filter(g => safeUrl(g.url));
  $('#checked').innerHTML = `<span>最近一次人工核对：<b>${esc(fullDate(ctx.meta.checkedAt))}</b></span><span>收录 <b>${ev.length}</b> 条行程、<b>${nw.length}</b> 条消息</span><span>其中待核实 <b>${un}</b> 条，单独标注</span>
    ${links.length ? `<span style="flex-basis:100%;display:flex;flex-wrap:wrap;gap:8px;margin-top:10px">${links.map(g => `<a class="pill" href="${esc(g.url)}" target="_blank" rel="noopener noreferrer" title="${esc(g.use || '')}">${esc(g.name)}</a>`).join('')}</span>` : ''}`;

  // image credits
  const list = $('#credits-list');
  const credits = (ctx.meta.credits || []).filter(c => safeUrl(c.sourcePage));
  list.innerHTML = `<p>成员照片为 EXIST《Cream Soda》（2023）与 REVERXE《Crown》（2026）官方概念照，专辑封面为各专辑官方数字封面，版权均归 SM Entertainment 及原权利人所有。本站为粉丝自制，仅作交流展示，不作商业用途。照片对应的成员以来源页面的文件名与说明为准。</p>
    ${credits.length ? `<ul style="margin-top:14px">${credits.map(c => `<li>${esc(c.title || c.file)} — ${esc(c.credit || '')} · <a class="src" href="${esc(c.sourcePage)}" target="_blank" rel="noopener noreferrer">来源页${icon('arrow')}</a></li>`).join('')}</ul>` : ''}`;
  $$('[data-open-credits]').forEach(b => b.addEventListener('click', () => overlay.open($('#credits'))));
}
