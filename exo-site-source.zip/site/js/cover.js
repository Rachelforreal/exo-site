/* 今日刊 — the 书刊 edition's first screen. One issue a day: the issue number is the day count
   since debut, the cover person is the member whose power is on (else the member of the day),
   the lyric follows the calendar, the cover lines say something true about today. */
import { $, $$, esc, todayStr, dayDiff, isUpcoming, md } from './util.js';
import { renderCheckin } from './checkin.js';
import { COVER_URL, STRIP_H, drawShareStrip, sizePicker, wrapLines } from './share.js'; /* share */

const WD = ['星期日', '星期一', '星期二', '星期三', '星期四', '星期五', '星期六'];
const MONTH = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];

export function initCover(ctx) {
  const root = $('#cover'); if (!root) return;
  const today = todayStr(), [ty, tm, td] = today.split('-').map(Number);
  const debut = ctx.archive?.debut || ctx.meta.debut;
  const no = dayDiff(today, debut);
  const order = ctx.members;

  /* the big thing ahead: nearest upcoming official release or concert, group or unit first */
  const ahead = ctx.events.filter(e => isUpcoming(e) && e.verification !== 'unverified' && /发行|演唱会/.test(e.category)).sort((a, b) => a.date.localeCompare(b.date));
  const big = ahead.find(e => e.members.includes('group') || e.members.length > 1) || ahead[0] || null;
  const bigD = big ? dayDiff(big.date) : null;

  const sameDay = d => +d.slice(5, 7) === tm && +d.slice(8, 10) === td;
  const annivAlbum = ctx.albums.find(a => sameDay(a.date) && a.date < today);
  const bday = order.find(m => sameDay(m.birth));
  const todayLine = bday ? `今天是 ${bday.en}（${bday.zh}）的生日。`
    : annivAlbum ? `今天是《${annivAlbum.title}》发行 ${ty - +annivAlbum.date.slice(0, 4)} 周年。`
    : big ? (bigD <= 0 ? `今天：${big.title}。` : `离 ${big.title} 还有 ${bigD} 天。`) : '今天没有大事，也是想念 EXO 的一天。';

  $('[data-issue-no]', root).textContent = no.toLocaleString('en-US');
  $('[data-issue-today]', root).innerHTML = `<b>${ty}.${String(tm).padStart(2, '0')}.${String(td).padStart(2, '0')} · ${WD[new Date(Date.UTC(ty, tm - 1, td)).getUTCDay()]}</b>出道第 ${no.toLocaleString('en-US')} 天。${esc(todayLine)}`;
  renderCheckin($('[data-checkin]', root), today, bday?.zh || '');
  $('[data-issue-line]', root).textContent = `Issue nº ${no.toLocaleString('en-US')} · ${td} ${MONTH[tm - 1]} ${ty}`;

  /* lyric: the album whose anniversary is today, otherwise rotate through the eras */
  const withLyric = ctx.albums.filter(a => a.lyric);
  const la = annivAlbum?.lyric ? annivAlbum : withLyric[no % withLyric.length];
  if (la) { $('[data-lyric-ko]', root).textContent = la.lyric[0]; $('[data-lyric-zh]', root).textContent = la.lyric[1]; $('[data-lyric-src]', root).textContent = `${la.lead} · ${la.title} · ${la.date.slice(0, 4)}`; }

  /* cover lines + table of contents: each line points into the page */
  const official = ctx.news.filter(n => n.verification === 'official').sort((a, b) => b.date.localeCompare(a.date))[0];
  const nextAnniv = ctx.albums.map(a => { let y = ty; let d = `${y}${a.date.slice(4)}`; if (d < today) d = `${++y}${a.date.slice(4)}`; return { a, d, n: y - +a.date.slice(0, 4), dd: dayDiff(d) }; }).filter(x => x.n > 0).sort((x, y) => x.dd - y.dd)[0];
  const lastRoad = (ctx.archive?.road || []).filter(r => r.d <= today).slice(-1)[0];
  $('[data-cover-lines]', root).innerHTML = [
    official && `<li><a href="#now"><small>此刻</small>${esc(official.title)}</a></li>`,
    big && `<li><a href="#schedule"><small>${bigD <= 0 ? '今天' : 'D-' + bigD}</small>${esc(big.title)}</a></li>`,
    nextAnniv && `<li><a href="#albums"><small>${nextAnniv.n} 周年</small>《${esc(nextAnniv.a.title)}》${md(nextAnniv.d)}</a></li>`,
  ].filter(Boolean).join('');
  const toc = [
    ['now', '此刻', official ? official.title : '有出处的正式消息'],
    ['members', '成员', '九种超能力 · 单人专栏'],
    ['schedule', '行程', big ? `${big.title} · ${bigD <= 0 ? '进行中' : 'D-' + bigD}` : '演出、发行、生日与纪念日'],
    ['albums', '专辑', nextAnniv ? `下一个纪念日：《${nextAnniv.a.title}》${nextAnniv.n} 周年 · D-${nextAnniv.dd}` : '每张专辑，一个 EXO 标志'],
    ['road', '来时路', lastRoad ? `最近一站：${lastRoad.t}` : '团体、小分队和九个人的路'],
    ['maker', 'L 卡', '你从哪首歌开始？'],
  ];
  $('[data-toc]', root).innerHTML = toc.map(([id, t, s], i) => `<li><a href="#${id}"><i>${['I', 'II', 'III', 'IV', 'V', 'VI'][i]}.</i><span><b>${t}</b><span>${esc(s)}</span></span></a></li>`).join('');
  $('[data-next]', root).innerHTML = big ? `<span>下一件大事</span><b>${esc(big.title)}</b><em>${bigD <= 0 ? '进行中' : 'D-' + bigD}</em>` : '';

  /* cover person */
  const pick = $('.issue__pick', root);
  const daily = no % order.length;
  let ci = Math.max(0, order.findIndex(m => m.id === document.documentElement.dataset.power));
  if (!order.some(m => m.id === document.documentElement.dataset.power)) ci = bday ? order.indexOf(bday) : daily; // birthday: his cover
  pick.innerHTML = order.map((m, i) => `<button type="button" data-ci="${i}" aria-label="${esc(m.en)} 的封面" style="--pc:${m.color}"></button>`).join('');
  const img = $('[data-cover-img]', root);
  function cover(i) {
    ci = (i + order.length) % order.length; const m = order[ci];
    img.classList.remove('is-in'); img.onload = () => img.classList.add('is-in');
    img.src = m.photo2 || m.photo; img.alt = `${m.en} 封面 · ${m.photo2 ? m.photo2Era : m.photoEra}`;
    if (img.complete && img.naturalWidth) img.classList.add('is-in');
    $('[data-cover-name]', root).textContent = m.en;
    $('[data-cover-line]', root).textContent = `${m.zh} · ${m.power.zh}`;
    root.style.setProperty('--pc', m.color);
    $('[data-cover-link]', root).href = `member.html?id=${m.id}`;
    $('[data-cover-link]', root).textContent = `打开 ${m.en} 的专栏 →`;
    $$('[data-ci]', pick).forEach(b => b.setAttribute('aria-pressed', String(+b.dataset.ci === ci)));
  }
  pick.addEventListener('click', e => { const b = e.target.closest('[data-ci]'); if (b) cover(+b.dataset.ci); });
  const mag = $('[data-cover]', root); let sx = null;
  mag.addEventListener('pointerdown', e => { sx = e.clientX; });
  mag.addEventListener('pointerup', e => { if (sx == null) return; const dx = e.clientX - sx; sx = null; if (Math.abs(dx) > 40) cover(ci + (dx < 0 ? 1 : -1)); });
  root.addEventListener('keydown', e => { if (e.key === 'ArrowRight') cover(ci + 1); if (e.key === 'ArrowLeft') cover(ci - 1); });
  document.addEventListener('power:change', e => { const i = order.findIndex(m => m.id === e.detail?.id); if (i >= 0) cover(i); });
  cover(ci);

  /* share:begin — save this issue as an image: 3:4 (default) / 1:1 / 9:16, layout re-flows, QR + URL strip */
  const sizer = sizePicker({ key: 'exo-cover-size', def: '3:4', keys: ['3:4', '1:1', '9:16'], host: $('.issue__btns', root), before: $('[data-save-cover]', root) });
  $('[data-save-cover]', root).addEventListener('click', async () => {
    const m = order[ci], [W, H] = sizer.dims(), sq = W === H, c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d');
    await Promise.all(['500 80px Jost', '600 80px "Noto Serif SC"', '400 30px "Cormorant Garamond"'].map(f => document.fonts.load(f, '星球今晚也在为你守住的王冠')).map(p => p.catch(() => {})));
    const ph = await new Promise(r => { const i = new Image(); i.onload = () => r(i); i.onerror = () => r(null); i.src = img.src; });
    const issueLine = $('[data-issue-line]', root).textContent, lyric = `「${$('[data-lyric-zh]', root).textContent}」`;
    const cover = (px, py, pw, phh, vy) => { if (!ph) return; const s = Math.max(pw / ph.width, phh / ph.height), iw = ph.width * s, ih = ph.height * s; x.save(); x.beginPath(); x.rect(px, py, pw, phh); x.clip(); x.drawImage(ph, px + (pw - iw) / 2, py + (phh - ih) * vy, iw, ih); x.restore(); };
    x.fillStyle = '#f4f2ee'; x.fillRect(0, 0, W, H); x.fillStyle = '#111';
    const stripTop = H - STRIP_H, SERIF = (w, px) => `${w} ${px}px "Noto Serif SC", serif`;
    if (!sq) {
      x.textAlign = 'center';
      x.font = '500 64px Jost, sans-serif'; x.fillText('exo', W / 2, 118);
      x.font = '600 200px "Noto Serif SC", serif'; x.fillText('星球', W / 2, 300);
      x.font = '400 30px "Cormorant Garamond", serif'; x.fillText(issueLine, W / 2, 360);
      x.font = SERIF(400, 32); const ly = wrapLines(x, lyric, W - 140);
      const lyH = ly.length * 44, px = 70, py = 400, pw = W - 140, phh = stripTop - 28 - lyH - py;
      cover(px, py, pw, phh, 0.18);
      const g = x.createLinearGradient(0, py + phh * 0.6, 0, py + phh); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.45)'); x.fillStyle = g; x.fillRect(px, py, pw, phh);
      x.textAlign = 'left'; x.fillStyle = '#fff'; x.font = '500 40px Jost, sans-serif'; x.fillText(m.en, px + 48, py + phh - 98);
      x.font = SERIF(400, 34); x.fillText(`—  ${m.zh} · ${m.power.zh}`, px + 48, py + phh - 44);
      x.fillStyle = '#111'; x.font = SERIF(400, 32); ly.forEach((l, i) => x.fillText(l, 70, py + phh + 56 + i * 44));
    } else {
      const pw = 470, px = W - 70 - pw, py = 70, phh = stripTop - 30 - py, cw = px - 70 - 30;
      cover(px, py, pw, phh, 0.18);
      x.textAlign = 'left'; x.font = '500 56px Jost, sans-serif'; x.fillText('exo', 70, 118);
      x.font = '600 190px "Noto Serif SC", serif'; x.fillText('星球', 66, 290);
      x.font = '400 26px "Cormorant Garamond", serif'; x.fillText(issueLine, 70, 338, cw);
      x.fillStyle = m.color; x.fillRect(70, 372, 56, 6);
      x.fillStyle = '#111'; x.font = '500 54px Jost, sans-serif'; x.fillText(m.en, 70, 450, cw);
      x.fillStyle = '#444'; x.font = SERIF(400, 30); x.fillText(`${m.zh} · ${m.power.zh}`, 70, 498, cw);
      x.fillStyle = '#111'; x.font = SERIF(400, 30); wrapLines(x, lyric, cw).slice(0, 6).forEach((l, i) => x.fillText(l, 70, 580 + i * 42));
    }
    drawShareStrip(x, { H, x0: 70, x1: W - 70, url: COVER_URL, ink: '#111', soft: '#666', dark: '#111', light: '#f4f2ee', font: (w, px) => `${w} ${px}px Jost, "Noto Serif SC", sans-serif`, lines: [issueLine, 'Photo © SM Entertainment'] });
    c.toBlob(b => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = `exo-issue-${no}-${m.id}.png`; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 4000); }, 'image/png');
  });
  /* share:end */
}
