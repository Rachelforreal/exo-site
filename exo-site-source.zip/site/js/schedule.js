// Schedule + ticketing: search, filters, favourites, month-grouped list, calendar export.
import { $, $$, esc, glyph, icon, badge, sources, safeUrl, reveal, store, toast, dayDiff, relDay, md, fullDate, weekday, cst, instant, isUpcoming } from './util.js';
import { memberChips } from './sections.js';

const hasTicket = e => !!(e.ticket && (e.ticket.platform || e.ticket.url || e.ticket.onSale || e.ticket.note)) || e.category === '票务';
const MONTH_EN = ['JANUARY', 'FEBRUARY', 'MARCH', 'APRIL', 'MAY', 'JUNE', 'JULY', 'AUGUST', 'SEPTEMBER', 'OCTOBER', 'NOVEMBER', 'DECEMBER'];

export function initSchedule(ctx, { openMember }) {
  const st = { q: '', when: 'upcoming', members: new Set(), cats: new Set(), ticket: false, star: false };
  const stars = new Set(store.get('exo-stars', []));
  const list = $('#sched-list'), qEl = $('#sched-q');
  const hay = new Map((ctx.calendar || ctx.events).map(e => [e.id, [e.title, e.summary, e.city, e.venue, e.category, e.channel, e.ticket?.platform, e.ticket?.note,
    ...(e.members || []).map(id => (id === 'group' ? 'EXO 团体 全员' : `${ctx.byId[id]?.en} ${ctx.byId[id]?.zh} ${ctx.byId[id]?.ko}`))].filter(Boolean).join(' ').toLowerCase()]));

  /* ---- chips ---- */
  const countFor = id => (ctx.calendar || ctx.events).filter(e => isUpcoming(e) && e.members.includes(id)).length;
  $('#sched-members').innerHTML = `<button class="pill pill--m" type="button" data-m="group" aria-pressed="false" style="--mc:#d6dcff">${glyph('galaxy')}EXO 团体<em>${countFor('group') || ''}</em></button>` +
    ctx.members.map(m => `<button class="pill pill--m" type="button" data-m="${m.id}" aria-pressed="false" style="--mc:${m.color}"><img src="${esc(m.thumb)}" alt="" loading="lazy">${esc(m.en)}<em>${countFor(m.id) || ''}</em></button>`).join('');
  const cats = [...new Set((ctx.calendar || ctx.events).map(e => e.category))];
  $('#sched-cats').innerHTML = cats.map(c => `<button class="pill" type="button" data-c="${esc(c)}" aria-pressed="false">${esc(c)}</button>`).join('');

  /* ---- one event ---- */
  const ticketHTML = e => {
    const t = e.ticket; if (!t || !(t.platform || t.url || t.onSale || t.note)) return '';
    const u = safeUrl(t.url);
    return `<p class="ev__ticket">${icon('ticket')}${t.platform ? `<b>${esc(t.platform)}</b>` : '<b>票务</b>'}${t.onSale ? `<span>${/演唱会|见面|票务/.test(e.category || '') ? '开票' : '开售'} ${esc(t.onSale)}</span>` : ''}${t.note ? `<span>${esc(t.note)}</span>` : ''}${u ? `<a class="src" href="${esc(u)}" target="_blank" rel="noopener noreferrer">去票务页${icon('arrow')}</a>` : ''}</p>`;
  };
  const evHTML = (e, i) => {
    const [, , d] = e.date.split('-'); const n = dayDiff(e.date); const done = !isUpcoming(e);
    const ongoing = !done && n < 0;
    const first = (e.members || []).find(id => id !== 'group'); const mc = first && e.members.length === 1 ? ctx.byId[first]?.color : '';
    const time = e.timeKST ? `首尔 ${e.timeKST} · 北京 ${cst(e.timeKST)}` : (e.timeLocal || '');
    const range = e.endDate && e.endDate !== e.date ? ` – ${md(e.endDate)}` : '';
    return `<article class="ev rv${done ? ' is-done' : ''}${e.verification === 'unverified' ? ' is-rumor' : ''}" id="ev-${esc(e.id)}" data-id="${esc(e.id)}" style="--i:${Math.min(i, 5)}${mc ? `;--mc:${mc}` : ''}">
      <div class="ev__date"><b>${d}</b><span>${weekday(e.date)}${range}</span>${done ? '' : `<em class="${n === 0 || ongoing ? 'is-today' : ''}">${ongoing ? '进行中' : relDay(n)}</em>`}</div>
      <div class="ev__body">
        <div class="ev__tags">${badge(e.verification)}<span class="tag">${esc(e.category)}</span>${memberChips(ctx, e.members, 'button')}</div>
        <h4>${esc(e.title)}</h4>
        <p class="ev__meta">${time ? `<span>${icon('cal')}${esc(time)}</span>` : ''}${e.city || e.venue ? `<span>${icon('pin')}${esc([e.city, e.venue].filter(Boolean).join(' · '))}</span>` : ''}</p>
        ${e.summary ? `<p class="ev__sum">${esc(e.summary)}</p>` : ''}
        ${ticketHTML(e)}
        ${e.missing ? `<p class="item__miss"><b>还缺什么</b>${esc(e.missing)}</p>` : ''}
        <div class="ev__src"><span>来源</span>${sources(e.sources) || '<span>暂无可公开链接</span>'}</div>
      </div>
      <div class="ev__side"><button class="star" type="button" data-star="${esc(e.id)}" aria-pressed="${stars.has(e.id)}" aria-label="收藏这条行程">${icon('star')}</button></div>
    </article>`;
  };

  /* ---- filter + render ---- */
  let shown = [];
  function filtered() {
    const terms = st.q.toLowerCase().split(/\s+/).filter(Boolean);
    return (ctx.calendar || ctx.events).filter(e => {
      const up = isUpcoming(e);
      if (st.when === 'upcoming' && !up) return false;
      if (st.when === 'done' && up) return false;
      if (st.members.size && !e.members.some(id => st.members.has(id))) return false;
      if (st.cats.size && !st.cats.has(e.category)) return false;
      if (st.ticket && !hasTicket(e)) return false;
      if (st.star && !stars.has(e.id)) return false;
      const h = hay.get(e.id); return terms.every(t => h.includes(t));
    }).sort((a, b) => (st.when === 'done' ? -1 : 1) * (a.date + (a.timeKST || '')).localeCompare(b.date + (b.timeKST || '')));
  }
  function render() {
    shown = filtered();
    const active = st.q || st.members.size || st.cats.size || st.ticket || st.star || st.when !== 'upcoming';
    $('#sched-reset').hidden = !active;
    const un = shown.filter(e => e.verification === 'unverified').length;
    $('#sched-count').textContent = shown.length ? `共 ${shown.length} 条${un ? `，其中 ${un} 条待核实` : ''}` : '';
    $('#sched-ics').hidden = !shown.length;
    if (!shown.length) {
      list.innerHTML = `<div class="sched__empty"><b>${st.star && !stars.size ? '还没有收藏任何行程' : '没有符合条件的行程'}</b>${st.star && !stars.size ? '点行程右侧的星标，就会出现在这里。' : '换个关键词，或者清除筛选看看全部。'}</div>`;
      return;
    }
    let html = '', cur = '', i = 0;
    for (const e of shown) {
      const ym = e.date.slice(0, 7);
      if (ym !== cur) { cur = ym; i = 0; const [y, m] = ym.split('-'); const n = shown.filter(x => x.date.startsWith(ym)).length;
        html += `<div class="month rv"><h3>${MONTH_EN[+m - 1]}<small>${y} 年 ${+m} 月</small></h3><span>${n} 条</span></div>`; }
      html += evHTML(e, i++);
    }
    list.innerHTML = html; reveal(list);
  }
  const sync = () => {
    $$('#sched-when button').forEach(b => b.setAttribute('aria-pressed', String(b.dataset.when === st.when)));
    $$('#sched-members .pill').forEach(b => b.setAttribute('aria-pressed', String(st.members.has(b.dataset.m))));
    $$('#sched-cats .pill').forEach(b => b.setAttribute('aria-pressed', String(st.cats.has(b.dataset.c))));
    $('#sched-ticket').checked = st.ticket; $('#sched-star').checked = st.star; if (qEl.value !== st.q) qEl.value = st.q;
    render();
  };

  let qt; qEl.addEventListener('input', () => { clearTimeout(qt); qt = setTimeout(() => { st.q = qEl.value.trim(); render(); }, 120); });
  $('#sched-when').addEventListener('click', e => { const b = e.target.closest('button'); if (b) { st.when = b.dataset.when; sync(); } });
  $('#sched-members').addEventListener('click', e => { const b = e.target.closest('.pill'); if (!b) return; st.members.has(b.dataset.m) ? st.members.delete(b.dataset.m) : st.members.add(b.dataset.m); sync(); });
  $('#sched-cats').addEventListener('click', e => { const b = e.target.closest('.pill'); if (!b) return; st.cats.has(b.dataset.c) ? st.cats.delete(b.dataset.c) : st.cats.add(b.dataset.c); sync(); });
  $('#sched-ticket').addEventListener('change', e => { st.ticket = e.target.checked; render(); });
  $('#sched-star').addEventListener('change', e => { st.star = e.target.checked; render(); });
  const reset = () => { st.q = ''; st.when = 'upcoming'; st.members.clear(); st.cats.clear(); st.ticket = st.star = false; sync(); };
  $('#sched-reset').addEventListener('click', reset);

  list.addEventListener('click', e => {
    const s = e.target.closest('[data-star]');
    if (s) {
      const id = s.dataset.star; const on = !stars.has(id); on ? stars.add(id) : stars.delete(id);
      s.setAttribute('aria-pressed', String(on)); store.set('exo-stars', [...stars]);
      toast(on ? '已收藏，只存在这台设备上' : '已取消收藏'); if (st.star && !on) render(); return;
    }
    const m = e.target.closest('button[data-member]');
    if (m) { if (m.dataset.member === 'group') { st.members.clear(); st.members.add('group'); sync(); } else openMember(m.dataset.member, m); }
  });

  /* ---- calendar export ---- */
  const icsEsc = s => String(s || '').replace(/\\/g, '\\\\').replace(/\n/g, '\\n').replace(/([,;])/g, '\\$1');
  const fold = l => l.replace(/(.{60})/g, '$1\r\n ').replace(/\r\n $/, '');
  const stamp = d => d.toISOString().replace(/[-:]/g, '').replace(/\.\d+/, '');
  const plus1 = s => { const [y, m, d] = s.split('-').map(Number); return new Date(Date.UTC(y, m - 1, d + 1)).toISOString().slice(0, 10).replace(/-/g, ''); };
  $('#sched-ics').addEventListener('click', () => {
    if (!shown.length) return;
    const now = stamp(new Date());
    const lines = ['BEGIN:VCALENDAR', 'VERSION:2.0', 'PRODID:-//EXO Planet fan site//ZH', 'CALSCALE:GREGORIAN', 'X-WR-CALNAME:EXO 行程'];
    for (const e of shown) {
      const tag = e.verification === 'unverified' ? '【待核实】' : '';
      const desc = [e.summary, e.timeLocal && !e.timeKST ? `当地时间：${e.timeLocal}` : '', e.missing ? `还缺什么：${e.missing}` : '', ...(e.sources || []).map(s => `来源：${s.name || ''} ${s.url || ''}`)].filter(Boolean).join('\n');
      lines.push('BEGIN:VEVENT', `UID:${e.id}@exo-planet`, `DTSTAMP:${now}`);
      if (e.timeKST) { const s = instant(e.date, e.timeKST); lines.push(`DTSTART:${stamp(s)}`, `DTEND:${stamp(new Date(+s + 2 * 36e5))}`); }
      else lines.push(`DTSTART;VALUE=DATE:${e.date.replace(/-/g, '')}`, `DTEND;VALUE=DATE:${plus1(e.endDate || e.date)}`);
      lines.push(fold(`SUMMARY:${icsEsc(tag + e.title)}`));
      if (e.city || e.venue) lines.push(fold(`LOCATION:${icsEsc([e.venue, e.city].filter(Boolean).join(', '))}`));
      lines.push(fold(`DESCRIPTION:${icsEsc(desc)}`), 'END:VEVENT');
    }
    lines.push('END:VCALENDAR');
    const a = document.createElement('a'); a.href = URL.createObjectURL(new Blob([lines.join('\r\n')], { type: 'text/calendar;charset=utf-8' }));
    a.download = 'exo-schedule.ics'; document.body.append(a); a.click(); a.remove(); setTimeout(() => URL.revokeObjectURL(a.href), 2000);
    toast(`已导出 ${shown.length} 条行程`);
  });

  /* ---- external API ---- */
  function focusEvent(id) {
    const e = (ctx.calendar || ctx.events).find(x => x.id === id); if (!e) return;
    if (!shown.some(x => x.id === id)) { st.q = ''; st.members.clear(); st.cats.clear(); st.ticket = st.star = false; st.when = isUpcoming(e) ? 'upcoming' : 'done'; sync(); }
    const el = document.getElementById(`ev-${id}`); if (!el) return;
    el.classList.add('is-in');
    (ctx.lenis ? ctx.lenis.scrollTo(el, { offset: -Math.max(110, innerHeight * 0.28), duration: 1.3 }) : el.scrollIntoView({ block: 'center' }));
    el.animate([{ boxShadow: '0 0 0 2px var(--ac), 0 0 60px -6px var(--ac)' }, { boxShadow: '0 0 0 0 transparent' }], { duration: 2200, delay: 500, easing: 'ease-out' });
  }
  function filterMember(id) {
    st.q = ''; st.cats.clear(); st.ticket = st.star = false; st.when = 'upcoming'; st.members.clear(); st.members.add(id); sync();
    const sec = $('#schedule'); ctx.lenis ? ctx.lenis.scrollTo(sec, { offset: -40, duration: 1.2 }) : sec.scrollIntoView();
  }
  function search(q) { reset(); st.q = q; st.when = 'all'; sync(); }
  sync();
  return { focusEvent, filterMember, search };
}
