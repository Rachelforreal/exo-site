// Site-wide search palette: members, schedule, albums, songs, channels and power themes.
import { $, $$, esc, glyph, icon, overlay, safeUrl, md, dayDiff, relDay, isUpcoming, VERIF } from './util.js';
import { POWERS, setPower } from './themes.js';

export function initSearch(ctx, api) {
  const pal = $('#palette'), input = $('#palette-q'), out = $('#palette-results');
  const idx = [];
  const add = (group, o) => idx.push({ group, ...o, hay: (o.title + ' ' + (o.keys || '') + ' ' + (o.sub || '')).toLowerCase() });
  for (const m of ctx.members) add('成员', { title: `${m.en} · ${m.zh}`, sub: `${m.power.zh} ${m.power.en} · ${m.role}`, keys: `${m.ko} ${m.koReal} ${m.id}`, img: m.thumb, tag: '名片', run: () => api.openMember(m.id) });
  for (const e of ctx.events) add('行程', { title: e.title, sub: `${md(e.date)} · ${isUpcoming(e) ? relDay(dayDiff(e.date)) : '已结束'} · ${e.category}${e.city ? ' · ' + e.city : ''}`, keys: `${e.venue || ''} ${e.summary || ''} ${e.ticket?.platform || ''} ${(e.members || []).map(i => ctx.byId[i]?.en + ' ' + ctx.byId[i]?.zh).join(' ')}`,
    fig: `<b>${md(e.date)}</b>`, tag: VERIF[e.verification]?.[0] || '待核实', up: isUpcoming(e), date: e.date, run: () => api.focusEvent(e.id) });
  for (const a of ctx.albums) {
    add('专辑', { title: a.title, sub: `${a.date.slice(0, 4)} · ${a.zh} · 主打 ${a.lead}`, keys: a.tagline, img: a.thumb, tag: '专辑', run: () => api.goAlbum(a.slug) });
    for (const t of a.tracks) add('歌曲', { title: t, sub: `收录于 ${a.title} · ${a.date.slice(0, 4)}`, img: a.thumb, tag: '歌曲', run: () => api.goAlbum(a.slug) });
  }
  for (const c of ctx.channels) add('渠道', { title: c.name, sub: `${c.zh} · ${c.use}`, keys: c.id, fig: icon('arrow'), tag: safeUrl(c.url) ? '打开' : '说明', run: () => { const u = safeUrl(c.url); if (u) window.open(u, '_blank', 'noopener'); else api.goSection('channels'); } });
  for (const p of POWERS) add('主题', { title: p.id === 'galaxy' ? '银河主题' : `${p.zh}主题 · ${p.name}`, sub: p.line, keys: `${p.en} theme 主题 属性 超能力`, fig: glyph(p.id), tag: '切换', run: () => setPower(p.id, { x: innerWidth / 2, y: innerHeight / 2 }) });

  const ORDER = ['成员', '行程', '专辑', '歌曲', '渠道', '主题'], LIMIT = { 成员: 9, 行程: 6, 专辑: 5, 歌曲: 6, 渠道: 4, 主题: 4 };
  let items = [], sel = 0;
  const mark = (s, terms) => { let h = esc(s); for (const t of terms) { if (!t) continue; const re = new RegExp(esc(t).replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'ig'); h = h.replace(re, m => `<mark>${m}</mark>`); } return h; };
  const row = (it, i, terms) => `<button class="palette__item${i === sel ? ' is-sel' : ''}" type="button" data-i="${i}" role="option" aria-selected="${i === sel}">
    <figure>${it.img ? `<img src="${esc(it.img)}" alt="" loading="lazy">` : (it.fig || '')}</figure><div><b>${mark(it.title, terms)}</b><small>${esc(it.sub || '')}</small></div><span>${esc(it.tag || '')}</span></button>`;

  function render() {
    const q = input.value.trim().toLowerCase(), terms = q.split(/\s+/).filter(Boolean); sel = 0; items = [];
    let html = '';
    if (!terms.length) {
      html += `<p class="palette__group">试试这些</p><div class="palette__hints">${['首尔', '开票', 'Crown', 'D.O.', '咆哮', '待核实', 'Weverse', '火焰'].map(h => `<button class="pill" type="button" data-hint="${h}">${h}</button>`).join('')}</div>`;
      const up = idx.filter(x => x.group === '行程' && x.up).sort((a, b) => a.date.localeCompare(b.date)).slice(0, 4);
      const groups = [['接下来的行程', up], ['成员', idx.filter(x => x.group === '成员')]];
      for (const [g, list] of groups) { if (!list.length) continue; html += `<p class="palette__group">${g}</p>`; for (const it of list) { html += row(it, items.length, terms); items.push(it); } }
    } else {
      const alias = { '咆哮': 'growl', '狼': 'wolf', '上瘾': 'overdose' };
      const tt = terms.map(t => alias[t] || t);
      const score = it => { let s = 0; for (const t of tt) { const p = it.hay.indexOf(t); if (p < 0) return -1; s += p === 0 ? 3 : it.title.toLowerCase().includes(t) ? 2 : 1; } if (it.up) s += 0.5; return s; };
      for (const g of ORDER) {
        const list = idx.filter(x => x.group === g).map(it => [score(it), it]).filter(x => x[0] >= 0).sort((a, b) => b[0] - a[0] || (a[1].date || '').localeCompare(b[1].date || '')).slice(0, LIMIT[g]);
        if (!list.length) continue; html += `<p class="palette__group">${g}</p>`;
        for (const [, it] of list) { html += row(it, items.length, tt); items.push(it); }
      }
      const act = { title: `在行程里搜索“${input.value.trim()}”`, sub: '用这个关键词筛选全部行程与票务', fig: icon('cal'), tag: '筛选', run: () => api.searchSchedule(input.value.trim()) };
      html += `<p class="palette__group">操作</p>` + row(act, items.length, []); items.push(act);
      if (items.length === 1) html = `<p class="palette__empty">没有找到“${esc(input.value.trim())}”。换个写法试试，比如成员的英文名或城市名。</p>` + html;
    }
    out.innerHTML = html; out.scrollTop = 0;
  }
  const move = d => { if (!items.length) return; sel = (sel + d + items.length) % items.length; $$('.palette__item', out).forEach((b, i) => { const on = i === sel; b.classList.toggle('is-sel', on); b.setAttribute('aria-selected', String(on)); if (on) b.scrollIntoView({ block: 'nearest' }); }); };
  const run = i => { const it = items[i]; if (!it) return; overlay.close(pal); setTimeout(() => it.run(), 60); };

  input.addEventListener('input', render);
  input.addEventListener('keydown', e => {
    if (e.key === 'ArrowDown') { e.preventDefault(); move(1); } else if (e.key === 'ArrowUp') { e.preventDefault(); move(-1); }
    else if (e.key === 'Enter' && !e.isComposing) { e.preventDefault(); run(sel); }
  });
  out.addEventListener('click', e => {
    const h = e.target.closest('[data-hint]'); if (h) { input.value = h.dataset.hint; render(); input.focus(); return; }
    const b = e.target.closest('.palette__item'); if (b) run(+b.dataset.i);
  });
  out.addEventListener('pointermove', e => { const b = e.target.closest('.palette__item'); if (b && +b.dataset.i !== sel) { sel = +b.dataset.i; $$('.palette__item', out).forEach((x, i) => x.classList.toggle('is-sel', i === sel)); } });

  const open = (q = '') => { input.value = q; render(); overlay.open(pal, { focus: input }); };
  $$('[data-open-search]').forEach(b => b.addEventListener('click', () => open()));
  document.addEventListener('keydown', e => {
    const typing = /^(INPUT|TEXTAREA|SELECT)$/.test(document.activeElement?.tagName || '');
    if ((e.key === 'k' || e.key === 'K') && (e.metaKey || e.ctrlKey)) { e.preventDefault(); pal.hidden ? open() : overlay.close(pal); }
    else if (e.key === '/' && !typing && !overlay.top()) { e.preventDefault(); open(); }
  });
  return { open };
}
