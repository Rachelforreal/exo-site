/* Sharing helpers: QR strip for exported images, export-size picker, member share button.
   QR encoding is kazuhikoarase's qrcode-generator (MIT, site/vendor/qrcode.mjs). */
import qrcode from '../vendor/qrcode.mjs';
import { store, toast } from './util.js';

export const SITE = 'https://www.exolneverland.com';
export const CARD_URL = `${SITE}/?from=lcard`;
export const COVER_URL = `${SITE}/?from=cover`;
export const memberUrl = id => `${SITE}/m/${id}/?from=share`;

/* export sizes: [width, height, label] */
export const SIZES = {
  '4:5': [1080, 1350, '4:5'],
  '3:4': [1080, 1440, '3:4 小红书'],
  '1:1': [1080, 1080, '1:1 朋友圈'],
  '9:16': [1080, 1920, '9:16 壁纸'],
};

/* QR: dark modules on a light plate, `mod` px per module, 2-module quiet zone included in the plate.
   Returns the plate size in px. */
const qrcodeCount = url => { const q = qrcode(0, 'M'); q.addData(url); q.make(); return q.getModuleCount(); };
export function drawQR(c, url, x, y, mod, { dark = '#111', light = '#fff', quiet = 2, radius = 0 } = {}) {
  const q = qrcode(0, 'M'); q.addData(url); q.make();
  const n = q.getModuleCount(), size = (n + quiet * 2) * mod;
  c.save(); c.fillStyle = light;
  if (radius && c.roundRect) { c.beginPath(); c.roundRect(x, y, size, size, radius); c.fill(); } else c.fillRect(x, y, size, size);
  c.fillStyle = dark;
  for (let r = 0; r < n; r++) for (let k = 0; k < n; k++) if (q.isDark(r, k)) c.fillRect(x + (k + quiet) * mod, y + (r + quiet) * mod, mod, mod);
  c.restore(); return size;
}

/* word-wrap for CJK/latin mixed text */
export function wrapLines(c, text, maxW) {
  const out = []; let cur = '';
  for (const ch of String(text)) { if (c.measureText(cur + ch).width > maxW && cur) { out.push(cur); cur = ch; } else cur += ch; }
  if (cur) out.push(cur); return out;
}

export const STRIP_H = 156;
/* Bottom strip: QR on the right, "exolneverland.com" + small lines on the left.
   Occupies y from H - STRIP_H to H, between x0 and x1. */
export function drawShareStrip(c, { H, x0, x1, url, lines = [], ink, soft, dark = '#111', light = '#fff', font }) {
  const mod = 4, pl = (qrcodeCount(url) + 4) * mod, plate = drawQR(c, url, x1 - pl, H - 24 - pl, mod, { dark, light, radius: 10 });
  const px = x1 - plate, base = H - 24 - 6;
  c.save(); c.textAlign = 'left'; c.textBaseline = 'alphabetic';
  const maxW = px - 28 - x0;
  const small = [...lines].reverse(); let y = base;
  c.fillStyle = soft; c.font = font(500, 22);
  for (const t of small) { c.fillText(fit(c, t, maxW), x0, y); y -= 32; }
  c.fillStyle = ink; c.font = font(700, 36); c.fillText('exolneverland.com', x0, y - 6);
  c.restore();
}
function fit(c, t, w) { if (c.measureText(t).width <= w) return t; while (t.length > 1 && c.measureText(t + '…').width > w) t = t.slice(0, -1); return t + '…'; }

/* size picker built on the existing .seg component; remembers the choice */
export function sizePicker({ key, def, keys, host, before, onChange }) {
  let cur = store.get(key, def); if (!keys.includes(cur)) cur = def;
  const el = document.createElement('div'); el.className = 'seg share-seg'; el.setAttribute('role', 'group'); el.setAttribute('aria-label', '导出尺寸');
  el.innerHTML = keys.map(k => `<button type="button" data-size="${k}" aria-pressed="${k === cur}">${SIZES[k][2]}</button>`).join('');
  el.addEventListener('click', e => {
    const b = e.target.closest('[data-size]'); if (!b || b.dataset.size === cur) return;
    cur = b.dataset.size; store.set(key, cur);
    el.querySelectorAll('[data-size]').forEach(x => x.setAttribute('aria-pressed', String(x === b))); onChange?.(cur);
  });
  host.insertBefore(el, before || null);
  return { get: () => cur, dims: () => SIZES[cur] };
}

/* member page: share button (Web Share, else copy link) */
export async function shareMember(m) {
  const url = memberUrl(m.id), title = `${m.en} ${m.zh} · EXO 星球`, text = `${m.en} 的超能力是「${m.power.zh}」`;
  if (navigator.share) { try { await navigator.share({ title, text, url }); } catch {} return; }
  try { await navigator.clipboard.writeText(url); }
  catch { const t = document.createElement('textarea'); t.value = url; t.style.cssText = 'position:fixed;opacity:0'; document.body.append(t); t.select(); try { document.execCommand('copy'); } catch {} t.remove(); }
  toast('链接已复制');
}
