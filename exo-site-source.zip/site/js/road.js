/* 来时路 / 综艺合集 — from the old 刊物 site, now in the shared style. Rows live in data/archive.json. */
import { $, $$, esc, glyph, todayStr, reduced } from './util.js';

export function initRoad(ctx) {
  const sec = $('#road'); if (!sec) return;
  const A = ctx.archive || {}, road = A.road || [], variety = A.variety || [];
  const list = $('#road-list', sec), vlist = $('#variety-list', sec), filters = $('.road__filters', sec);
  const who = w => w === 'exo' ? { label: 'EXO', color: 'var(--ac)' } : w === 'unit' ? { label: '小分队', color: 'var(--ac-2)' } : { label: ctx.byId[w]?.en || w, color: ctx.byId[w]?.color || 'var(--ac)', id: w };

  filters.innerHTML = [['all', '全部'], ['exo', '团体'], ['unit', '小分队']].map(([k, l]) => `<button class="pill" type="button" data-f="${k}" aria-pressed="${k === 'all'}">${k === 'exo' ? glyph('galaxy') : ''}${l}</button>`).join('')
    + ctx.members.map(m => `<button class="pill pill--m" type="button" data-f="${m.id}" aria-pressed="false" style="--mc:${m.color}">${glyph(m.id)}${esc(m.en)}</button>`).join('');

  let f = 'all';
  function render() {
    const t = todayStr();
    const rows = road.filter(r => f === 'all' || r.who === f || (r.who === 'unit' && ctx.byId[f] && (r.s + r.t).includes(ctx.byId[f].zh))).sort((a, b) => a.d.localeCompare(b.d));
    const years = [...new Set(rows.map(r => r.d.slice(0, 4)))];
    list.innerHTML = years.map(y => `<li class="ry rv"><p class="ry__y">${y}</p><ol class="ry__items">${rows.filter(r => r.d.startsWith(y)).map(r => {
      const w = who(r.who), fut = r.d > t, date = r.approx || r.d.slice(5).replace('-', '.');
      const title = r.src ? `<a href="${esc(r.src)}" target="_blank" rel="noopener noreferrer">${esc(r.t)}</a>` : esc(r.t);
      const tag = w.id ? `<a class="rd__who" href="member.html?id=${w.id}"><i></i>${esc(w.label)}</a>` : `<span class="rd__who"><i></i>${esc(w.label)}</span>`;
      return `<li class="rd rd--${r.kind}${fut ? ' rd--future' : ''}" style="--pc:${w.color}"><time datetime="${r.d}">${date}</time>${tag}<span class="rd__t"><b>${title}</b><small>${esc(r.s)}</small></span></li>`; }).join('')}</ol></li>`).join('')
      || '<li class="ry"><p class="ry__y">—</p><p class="road__note">这一栏还没有记录。</p></li>';
    list.querySelectorAll('.rv').forEach(n => n.classList.add('is-in'));
  }
  filters.addEventListener('click', e => {
    const b = e.target.closest('[data-f]'); if (!b || b.dataset.f === f) return; f = b.dataset.f;
    $$('[data-f]', filters).forEach(x => x.setAttribute('aria-pressed', String(x === b)));
    if (document.startViewTransition && !reduced) document.startViewTransition(render); else render();
  });
  render();

  vlist.innerHTML = variety.map((v, i) => {
    const q = `https://search.bilibili.com/all?keyword=${encodeURIComponent('EXO ' + v.t)}`;
    return `<li class="vr${i && variety[i - 1].y === v.y ? ' is-same' : ''}"><span class="vr__y">${esc(v.y)}</span><span class="vr__t"><b>${esc(v.zh)}</b><span>${esc(v.t)}</span>${v.note ? `<small>${esc(v.note)}</small>` : ''}</span><span class="vr__m"><b>${esc(v.who)}</b>${esc(v.p)} · ${esc(v.d)}</span><a class="vr__go" href="${q}" target="_blank" rel="noopener noreferrer">B 站 ↗</a></li>`;
  }).join('');

  const tabs = $$('[data-tab]', sec), panes = $$('[data-pane]', sec);
  tabs.forEach(b => b.addEventListener('click', () => {
    tabs.forEach(x => { x.setAttribute('aria-selected', String(x === b)); x.setAttribute('aria-pressed', String(x === b)); });
    panes.forEach(p => (p.hidden = p.dataset.pane !== b.dataset.tab));
    window.ScrollTrigger?.refresh();
  }));
}
