// Small shared helpers.
export const $ = (s, r = document) => r.querySelector(s);
export const $$ = (s, r = document) => [...r.querySelectorAll(s)];
export const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
export const safeUrl = u => (/^https?:\/\//i.test(u || '') ? u : '');
export const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
export const clamp = (v, a, b) => Math.min(b, Math.max(a, v));

export const glyph = (id, cls = 'glyph') => `<svg class="${cls}" viewBox="0 0 48 48" aria-hidden="true"><use href="#g-${id}"/></svg>`;
export const icon = id => `<svg viewBox="0 0 24 24" aria-hidden="true"><use href="#i-${id}"/></svg>`;

/* ---- dates: the site reads dates as Korea time and shows Beijing time next to it ---- */
const TODAY_OVERRIDE = new URLSearchParams(location.search).get('today'); // ?today=2026-11-12 for testing check-ins / birthdays
export const todayStr = () => (/^\d{4}-\d{2}-\d{2}$/.test(TODAY_OVERRIDE || '') ? TODAY_OVERRIDE : new Date().toLocaleDateString('sv-SE', { timeZone: 'Asia/Shanghai' }));
const utc = s => { const [y, m, d] = s.split('-').map(Number); return Date.UTC(y, m - 1, d); };
export const dayDiff = (a, b = todayStr()) => Math.round((utc(a) - utc(b)) / 864e5);
const WD = ['周日', '周一', '周二', '周三', '周四', '周五', '周六'];
export const weekday = s => WD[new Date(utc(s)).getUTCDay()];
export const md = s => { const [, m, d] = s.split('-'); return `${+m}.${d}`; };
export const fullDate = s => { const [y, m, d] = s.split('-'); return `${y}.${m}.${d}`; };
export const cst = t => { if (!t) return ''; const [h, m] = t.split(':').map(Number); return `${String((h + 23) % 24).padStart(2, '0')}:${String(m).padStart(2, '0')}`; };
export const instant = (date, timeKST) => new Date(`${date}T${timeKST || '00:00'}:00+09:00`);
export const relDay = n => (n === 0 ? '今天' : n === 1 ? '明天' : n === 2 ? '后天' : n > 0 ? `${n} 天后` : n === -1 ? '昨天' : `${-n} 天前`);
export const dateRange = e => (e.endDate && e.endDate !== e.date ? `${fullDate(e.date)} – ${md(e.endDate)}` : fullDate(e.date));
export const isUpcoming = e => dayDiff(e.endDate || e.date) >= 0 && e.status !== 'done';

/* ---- storage ---- */
export const store = {
  get(k, d) { try { const v = localStorage.getItem(k); return v == null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch {} },
};

/* ---- verification ---- */
export const VERIF = { official: ['官方', 'official'], media: ['媒体', 'media'], unverified: ['待核实', 'rumor'] };
export const badge = v => { const [t, c] = VERIF[v] || VERIF.unverified; return `<span class="badge badge--${c}">${t}</span>`; };
export const sources = list => (list || []).filter(s => s && (s.name || s.url)).map(s => {
  const u = safeUrl(s.url); const name = esc(s.name || new URL(u).hostname);
  return u ? `<a class="src" href="${esc(u)}" target="_blank" rel="noopener noreferrer">${name}${icon('arrow')}</a>` : `<span>${name}</span>`;
}).join('');

/* ---- toast ---- */
let toastT;
export function toast(msg) {
  const el = $('#toast'); el.textContent = msg; el.classList.add('is-on');
  clearTimeout(toastT); toastT = setTimeout(() => el.classList.remove('is-on'), 2600);
}

/* ---- overlays ---- */
const stack = [];
export const overlay = {
  lenis: null,
  open(el, { focus } = {}) {
    if (!el.hidden) return;
    el._return = document.activeElement; el.hidden = false; el.classList.remove('is-out'); stack.push(el);
    this.lenis?.stop(); document.documentElement.style.overflow = 'hidden';
    requestAnimationFrame(() => (focus || el.querySelector('input, button, [href]'))?.focus({ preventScroll: true }));
  },
  close(el) {
    if (!el || el.hidden) return;
    const done = () => { el.hidden = true; el.classList.remove('is-out'); el.dispatchEvent(new CustomEvent('overlay:closed')); };
    if (el.id === 'sheet' && !reduced) { el.classList.add('is-out'); setTimeout(done, 380); } else done();
    stack.splice(stack.indexOf(el), 1);
    if (!stack.length) { this.lenis?.start(); document.documentElement.style.overflow = ''; }
    el._return?.focus?.({ preventScroll: true });
  },
  top: () => stack[stack.length - 1],
};
document.addEventListener('click', e => { const c = e.target.closest('[data-close]'); if (c) overlay.close(c.closest('.dial, .sheet, .palette, .mv, .credits')); });
document.addEventListener('keydown', e => {
  const top = overlay.top(); if (!top) return;
  if (e.key === 'Escape') { e.preventDefault(); overlay.close(top); return; }
  if (e.key === 'Tab') { // keep focus inside the open overlay
    const f = $$('a[href], button:not([disabled]), input, [tabindex]:not([tabindex="-1"])', top).filter(n => n.offsetParent !== null);
    if (!f.length) return; const first = f[0], last = f[f.length - 1];
    if (e.shiftKey && document.activeElement === first) { e.preventDefault(); last.focus(); }
    else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
  }
});

/* ---- reveal on scroll ---- */
const io = 'IntersectionObserver' in window ? new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('is-in'); io.unobserve(e.target); } }), { rootMargin: '0px 0px -8% 0px', threshold: 0.05 }) : null;
export const reveal = (root = document) => $$('.rv:not(.is-in)', root).forEach(n => (io ? io.observe(n) : n.classList.add('is-in')));

/* ---- drag-to-scroll for native horizontal scrollers ---- */
export function dragScroll(el) {
  let down = false, sx = 0, sl = 0, moved = 0;
  el.addEventListener('pointerdown', e => { if (e.pointerType !== 'mouse') return; down = true; sx = e.clientX; sl = el.scrollLeft; moved = 0; });
  window.addEventListener('pointermove', e => { if (!down) return; const dx = e.clientX - sx; moved = Math.max(moved, Math.abs(dx)); if (moved > 4) { el.classList.add('is-drag'); el.scrollLeft = sl - dx; } });
  window.addEventListener('pointerup', () => { if (!down) return; down = false; setTimeout(() => el.classList.remove('is-drag'), 0); });
  el.addEventListener('click', e => { if (moved > 6) { e.preventDefault(); e.stopPropagation(); moved = 0; } }, true);
}
